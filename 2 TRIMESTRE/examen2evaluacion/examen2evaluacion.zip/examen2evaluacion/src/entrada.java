import java.util.ArrayList;

public class entrada {


    arraylist lisa= new ArrayList();
    //crea una aplicacion que tenga lo siguiente ,un arraylist que permita guardar un conjunto de productos ,cada producto consta de nombre y precio
    //lista de todos los arraylist con su nombre y precio
    //pide por consola su precio minimo y muestra todos sus productos como minimo ese precio
    // lista de contenidos de mayor a menor
lista.add("elemento a añadir")

for (int i=0;i<listaString.size();i++){
        String elemento = listaString.get(i);
        System.out.println(elemento);
    }
//ejercicio 2
public class ControlDeFlujo {

    int nota;
    public void estructuraIfBasica(){
        nota = 7;
        if (nota <5){
            System.out.println("El examen está suspenso");
        }
        else{
            System.out.println("El examen está aprobado");
        }
    }

    public static void main(String[]args){
        ControlDeFlujo control = new ControlDeFlujo();
        control.estructuraIfBasica();
    }
}

        int nota;

        public void estructuraSwitch() {
            nota = 8;
            switch (nota) {
                case 1:
                    System.out.println("La note obtenida es un 1");
                    break;
                case 5:
                    System.out.println("La nota obtenida es un 5");
                    break;
                case 10:
                    System.out.println("La nota obtenida es un 10");
                    break;
                default:
                    System.out.println("La nota obtenida no está contemplada en este bloque");
                    break;
            }
        }

        public static void main(String[] args) {
            ControlDeFlujo control = new ControlDeFlujo();
            control.estructuraSwitch();
        }
    }

