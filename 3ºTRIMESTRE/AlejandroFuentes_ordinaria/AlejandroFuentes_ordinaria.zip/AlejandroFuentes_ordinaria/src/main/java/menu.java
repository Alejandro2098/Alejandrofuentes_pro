Camiseta, 10.7, 5
Pantalón, 25.5, 10
Zapatos, 45.0, 7
Bolso, 35.2, 3
Gorra, 8.5, 12