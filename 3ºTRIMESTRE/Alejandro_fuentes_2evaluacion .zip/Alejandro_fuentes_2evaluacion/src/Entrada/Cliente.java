package Entrada;

public class Cliente {
    // Clase Cliente
    class Cliente {
        private String nombre;
        private ArrayList<Entrada.Entrada.Consumicion> consumiciones;

        public Cliente(String nombre) {
            this.nombre = nombre;
            this.consumiciones = new ArrayList<>();
        }

        public String getNombre() {
            return nombre;
        }

        public void agregarConsumicion(Entrada.Entrada.Consumicion c) {
            consumiciones.add(c);
        }

        public void mostrarConsumiciones() {
            System.out.println("\nConsumiciones de " + nombre + ":");
            for (Entrada.Entrada.Consumicion c : consumiciones) {
                System.out.println(c);
            }
        }

        public double calcularTotal() {
            double total = 0;
            for (Entrada.Entrada.Consumicion c : consumiciones) {
                total += c.getPrecio();
            }
            return total;
        }
    }
