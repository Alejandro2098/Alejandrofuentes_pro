package Entrada;

public class Entrada {

    import java.util.ArrayList;
import java.util.Scanner;

    // Clase base Consumicion
    abstract class Consumicion {
        protected String nombre;
        protected double precio;

        public Consumicion(String nombre, double precio) {
            this.nombre = nombre;
            this.precio = precio;
        }

        public String getNombre() {
            return nombre;
        }

        public double getPrecio() {
            return precio;
        }


        public String toString() {
            return nombre + " - $" + precio;
        }
    }




    // Clase Main con menú
