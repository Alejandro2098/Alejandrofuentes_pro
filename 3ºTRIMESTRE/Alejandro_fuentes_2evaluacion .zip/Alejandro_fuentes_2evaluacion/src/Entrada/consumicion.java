package Entrada;

public class consumicion {
    // Clases hijas
    class Comida extends Entrada.Entrada.Consumicion {
        private int calorias;

        public Comida(String nombre, double precio, int calorias) {
            super(nombre, precio);
            this.calorias = calorias;
        }

        public String toString() {
            return super.toString() + " - " + calorias + " kcal";
        }
    }

    class Bebida extends Entrada.Entrada.Consumicion {
        private int mililitros;

        public Bebida(String nombre, double precio, int mililitros) {
            super(nombre, precio);
            this.mililitros = mililitros;
        }


        public String toString() {
            return super.toString() + " - " + mililitros + " ml";
        }
    }

    class Racion extends Entrada.Entrada.Consumicion {
        private int cantidad;

        public Racion(String nombre, double precio, int cantidad) {
            super(nombre, precio);
            this.cantidad = cantidad;
        }


        public String toString() {
            return super.toString() + " - " + cantidad + " platos";
        }
    }

}
