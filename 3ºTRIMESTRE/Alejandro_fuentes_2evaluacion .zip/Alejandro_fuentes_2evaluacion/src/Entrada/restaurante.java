package Entrada;

public class restaurante {
    // Clase Restaurante
    class Restaurante {
        private ArrayList<Cliente> clientes;
        private double caja;

        public Restaurante() {
            clientes = new ArrayList<>();
            caja = 0;
        }

        public void admitirCliente(String nombre) {
            clientes.add(new Cliente(nombre));
        }

        public Cliente buscarCliente(String nombre) {
            for (Cliente c : clientes) {
                if (c.getNombre().equalsIgnoreCase(nombre)) {
                    return c;
                }
            }
            return null;
        }

        public void cobrarCliente(Cliente c) {
            double total = c.calcularTotal();
            caja += total;
            System.out.println("Total a pagar por " + c.getNombre() + ": $" + total);
        }

        public void verTotalCaja() {
            System.out.println("Total en caja: $" + caja);
        }

        public void mostrarClientes() {
            System.out.println("\nLista de clientes:");
            for (Cliente c : clientes) {
                System.out.println(c.getNombre());
            }
        }
    }
