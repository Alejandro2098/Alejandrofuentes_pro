public class Alejandrofuentesexam {
    //ejercicio2
    //ejercicio3
    // /ejercicio4
public static <input> void main(String[]args) { public class ejercicio2(){;

    int i = 10;
    Object numero_usuario; int(input("Introduce un número entre 1 y 100: ");


    numeros_generados =[random.randint(1, 100) for=in range (10)]

    Object numero_maximo = max(numeros_generados);
    Object numero_minimo = min(numeros_generados);
    Object numero_medio = sum(numeros_generados) / len(numeros_generados);
    Object suma_total = sum(numeros_generados);
    Object numero_encontrado = numero_usuario;
    in numeros_generados;
}

    public class ejercicio3;(){
        printf("Números generados: {numeros_generados}");
        printf("El número más grande)";

                String clave_correcta = "1234";
        String intentos_restantes = "4";

        while (tentos_restantes > 0);
        clave_usuario = input("Introduce la clave de la caja fuerte (4 dígitos): ");

        if (clave_usuario == clave_correcta){}
        print("Perfecto, la caja ha sido abierta");
        return;
                    else;
        intentos_restantes -= 1;
        if( intentos_restantes > 0);{
            print("Intento fallido, prueba de nuevo");
            else:
            print("Lo siento, caja bloqueada");
        }
        while;

        int (numero_decimal);
        int(new input("Introduce un número decimal positivo: "));

        if (numero_decimal < 0);
        print("No se puede realizar la operación con números negativos.");
    }
}

    public static void ejercicio4() {
        print("Elige una base para convertir:");
        print("1. Base 2 (Binario)");
        print("2. Base 8 (Octal)");
        print("3. Base 16 (Hexadecimal)");
        opcion = imput("Selecciona una opción (1, 2, o 3): ");

        if (opcion == '1') {
            printf("El número en base 2 es: {bin(numero_decimal)[2:]}");
            elif opcion; =='2';
            printf("El número en base 8 es: {oct(numero_decimal)[2:]}");
            elif opcion; =='3';
            printf("El número en base 16 es: {hex(numero_decimal)[2:].upper()}");
            printf("Opción no válida, por favor selecciona 1, 2, o 3.");
        }
    }



}

