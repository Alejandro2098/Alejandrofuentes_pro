import jdk.jshell.execution.LocalExecutionControl;

import java.util.Scanner;

public class Ejercicio1 {
    Scanner in = new Scanner(System.in);

    public Scanner getIn() {
        return in;

    }


    public static void main(String[] args){
            System.out.println("Sacar mensaje por consola");
        Scanner in = new Scanner(System.in);
        System.out.println("Como te llamas");
        System.out.println("Dinero que dispones para la compra ");
        System.out.println("Cuanto cuesta la play5 que te quieres comprar");
        System.out.println("Cuanto cuesta el Iphone15 que te quieres comprar");
        System.out.println("Dime si es true o false ");
        System.out.println("dime si puedo comprar la play 5");
        System.out.println("Dime si puedo comprar el iphone");

        }
    }


