

import java.awt.datatransfer.SystemFlavorMap;
import java.sql.SQLOutput;
import java.util.Scanner;


public class Ejercicio1 {
    static Scanner escribirTeclado = new Scanner ( System.in);
    public static void main (String[] args){
    ejercicio1();
    ejercicio2();


    }
    public static void ejercicio1(){

      final String NOMBRE="Luis González";
      final String DIRECCION="C/ Maria de Molina";
      final int PORTAL =51;
      final int PISO = 1;
      final char LETRA = 'a';
      final int CODIGO=91023;
      final String PROVINCIA="madrid";
      final String POBLACION="madrid";
      final String PAIS="españa";

      System.out.println(NOMBRE);
      System.out.printf("%s n %d %d%c\n", DIRECCION,PORTAL,PISO,LETRA);
        System.out.printf("%d,%s %s\n", CODIGO,POBLACION,PROVINCIA);
        System.out.println(PAIS);
    }
    public static void ejercicio2(){



    }


}








